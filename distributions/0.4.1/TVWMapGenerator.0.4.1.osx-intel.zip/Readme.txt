- Extract
- Go to TVWMapGenerator
- Run TVWMapGenerator.exe


Use
 - Generate to create the terrain
 - Randomize Props to place city and productions randomly
 - Write to write level to saves directory

Experiment with settings for different layouts
Water level is a bit buggy
Bridges are your friend for hard to reach spots

