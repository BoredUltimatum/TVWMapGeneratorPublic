- Extract
- Go to TVWMapGenerator
- Run TVWMapGenerator.exe


Use
 - Generate to create the terrain
 - Randomize Props to place city and productions randomly
 - Write to write level to saves directory

Experiment with settings for different layouts
Water level currently bugged

